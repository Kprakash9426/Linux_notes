#!/bin/bash
# disk_alert.sh - warn when a disk is filling up
# Usage: ./disk_alert.sh [percent]     (default warning level is 80)
THRESHOLD="${1:-80}"
LOGFILE="$HOME/disk_alert.log"

df -hP | awk 'NR>1 {print $5, $6}' | while read -r usage mount; do
    percent="${usage%\%}"                    # remove the % sign: 85% becomes 85
    if [ "$percent" -ge "$THRESHOLD" ]; then
        msg="$(date '+%F %T') WARNING: $mount is ${percent}% full"
        echo "$msg"
        echo "$msg" >> "$LOGFILE"
    fi
done

echo "Disk check finished (warning level ${THRESHOLD}%)"
