#!/bin/bash
# greet.sh - ask for a name and greet the user
read -p "What is your name? " name

if [ -z "$name" ]; then
    echo "You did not type a name!"
    exit 1
fi

echo "Welcome to bash scripting, $name!"
