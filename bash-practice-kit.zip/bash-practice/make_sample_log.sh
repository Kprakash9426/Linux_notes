#!/bin/bash
# make_sample_log.sh - creates a fake application log to practise on
LOG="${1:-app.log}"
RANDOM=42                                  # fixed starting point = same data every time
levels=(INFO INFO INFO INFO WARN ERROR)    # an array: a list of values

: > "$LOG"                                 # empty the file
for i in $(seq 1 200); do
    ip="192.168.1.$((RANDOM % 5 + 10))"
    level="${levels[RANDOM % 6]}"
    echo "$(date '+%F %T') $ip $level request $i handled" >> "$LOG"
done

echo "Created $LOG with $(wc -l < "$LOG") lines"
