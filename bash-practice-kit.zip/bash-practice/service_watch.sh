#!/bin/bash
# service_watch.sh - restart a service if it has stopped
# Usage: sudo ./service_watch.sh <service-name> [logfile]
SERVICE="${1:-sshd}"
LOG="${2:-service_watch.log}"

log() {                                    # a function: print AND save a message
    echo "$(date '+%F %T') $1" | tee -a "$LOG"
}

if systemctl is-active --quiet "$SERVICE"; then
    log "OK: $SERVICE is running"
else
    log "PROBLEM: $SERVICE is not running - trying to restart"
    systemctl restart "$SERVICE"
    sleep 3
    if systemctl is-active --quiet "$SERVICE"; then
        log "FIXED: $SERVICE restarted successfully"
    else
        log "FAILED: $SERVICE is still down - call the admin!"
        exit 1
    fi
fi
