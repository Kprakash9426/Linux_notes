#!/bin/bash
# number_check.sh - is a number positive, negative or zero?
read -p "Enter a number: " num

# make sure the user really typed a whole number
if ! [[ "$num" =~ ^-?[0-9]+$ ]]; then
    echo "'$num' is not a whole number."
    exit 1
fi

if [ "$num" -gt 0 ]; then
    echo "$num is positive"
elif [ "$num" -lt 0 ]; then
    echo "$num is negative"
else
    echo "$num is zero"
fi
