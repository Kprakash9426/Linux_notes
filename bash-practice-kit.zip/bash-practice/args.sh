#!/bin/bash
# args.sh - shows how command line arguments work
echo "Script name     : $0"
echo "First argument  : $1"
echo "Second argument : $2"
echo "How many args   : $#"
echo "All of them     : $*"
