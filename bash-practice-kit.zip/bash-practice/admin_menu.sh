#!/bin/bash
# admin_menu.sh - a small interactive menu
while true; do
    echo
    echo "======= ADMIN MENU ======="
    echo "1) Show disk space"
    echo "2) Show memory"
    echo "3) Show logged-in users"
    echo "4) Show date and time"
    echo "q) Quit"
    read -p "Choose an option: " choice

    case "$choice" in
        1) df -h ;;
        2) free -h ;;
        3) who ;;
        4) date ;;
        q|Q) echo "Bye!"; break ;;
        *) echo "Invalid choice, try again." ;;
    esac
done
