#!/bin/bash
# check_servers.sh - ping every server listed in a text file
# Usage: ./check_servers.sh [file]     (default file: servers.txt)
FILE="${1:-servers.txt}"

if [ ! -f "$FILE" ]; then
    echo "File not found: $FILE"
    exit 1
fi

up=0
down=0
while read -r host; do
    [ -z "$host" ] && continue              # skip empty lines
    [[ "$host" == \#* ]] && continue        # skip lines that start with #
    if ping -c 1 -W 2 "$host" > /dev/null 2>&1; then
        echo "[ UP   ] $host"
        up=$((up + 1))
    else
        echo "[ DOWN ] $host"
        down=$((down + 1))
    fi
done < "$FILE"

echo "Summary: $up up, $down down"
