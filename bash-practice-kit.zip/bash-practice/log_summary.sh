#!/bin/bash
# log_summary.sh - summarise a log file
# Usage: ./log_summary.sh [logfile]     (default: app.log)
LOG="${1:-app.log}"

if [ ! -f "$LOG" ]; then
    echo "Log file not found: $LOG"
    exit 1
fi

echo "===== Report for $LOG ====="
echo "Total lines : $(wc -l < "$LOG")"
echo "INFO        : $(grep -c ' INFO ' "$LOG")"
echo "WARN        : $(grep -c ' WARN ' "$LOG")"
echo "ERROR       : $(grep -c ' ERROR ' "$LOG")"

echo
echo "Top 3 IP addresses with the most ERRORs (count, IP):"
grep ' ERROR ' "$LOG" | awk '{print $3}' | sort | uniq -c | sort -rn | head -n 3

echo
echo "Last 3 ERROR lines:"
grep ' ERROR ' "$LOG" | tail -n 3
