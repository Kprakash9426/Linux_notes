#!/bin/bash
# check_port.sh - is a TCP port open on a host?
# Usage: ./check_port.sh <host> <port>
if [ $# -ne 2 ]; then
    echo "Usage: $0 <host> <port>"
    exit 1
fi

host="$1"
port="$2"

if timeout 3 bash -c "echo > /dev/tcp/$host/$port" 2>/dev/null; then
    echo "OPEN   : $host port $port is reachable"
else
    echo "CLOSED : $host port $port is closed, blocked, or the host is down"
    exit 2
fi
