#!/bin/bash
# create_users.sh - create the users listed in a file
# Usage: ./create_users.sh [file] [dry|real]
# ALWAYS run it in "dry" mode first - dry mode only shows what would happen.
FILE="${1:-users.txt}"
MODE="${2:-dry}"

if [ ! -f "$FILE" ]; then
    echo "File not found: $FILE"
    exit 1
fi

if [ "$MODE" = "real" ] && [ "$(id -u)" -ne 0 ]; then
    echo "Real mode needs root. Run with: sudo $0 $FILE real"
    exit 1
fi

while read -r user; do
    [ -z "$user" ] && continue                  # skip empty lines
    [[ "$user" == \#* ]] && continue            # skip comment lines
    if id "$user" &> /dev/null; then
        echo "SKIP     $user already exists"
    elif [ "$MODE" = "real" ]; then
        useradd -m "$user" && echo "CREATED  $user"
    else
        echo "DRY-RUN  would create $user"
    fi
done < "$FILE"
