#!/bin/bash
# loops_demo.sh - for loop, case statement and while loop together

echo "--- for loop: count 1 to 3 ---"
for i in {1..3}; do
    echo "Number $i"
done

echo
echo "--- for loop over words, with case ---"
for fruit in apple banana kiwi; do
    case "$fruit" in
        apple)  echo "$fruit is red" ;;
        banana) echo "$fruit is yellow" ;;
        *)      echo "$fruit: I do not know its colour" ;;
    esac
done

echo
echo "--- while loop: countdown ---"
count=3
while [ "$count" -gt 0 ]; do
    echo "$count..."
    count=$((count - 1))
done
echo "Liftoff!"
