#!/bin/bash
# debug_demo.sh - see what set -x does
set -x
name="Zaira"
echo "Hi $name"
count=$((2 + 3))
echo "Count is $count"
