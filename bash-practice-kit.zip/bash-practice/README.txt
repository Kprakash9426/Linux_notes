BASH PRACTICE KIT
=================
1. Copy this folder to your Linux machine (or WSL):   cp -r bash-practice ~/
2. Go inside:                                         cd ~/bash-practice
3. Make every script runnable:                         chmod +x *.sh
4. Run one:                                            ./hello.sh

TIP: reading is not enough - TYPE each script yourself first, then compare with
these files. Break them on purpose and read the error messages.
Never run create_users.sh in 'real' mode until you understand it.
