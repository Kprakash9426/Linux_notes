#!/bin/bash
# system_health.sh - a quick health report of this server
echo "=============================================="
echo " Health report for $(hostname)"
echo " $(date '+%d-%b-%Y %H:%M:%S')"
echo "=============================================="

echo
echo "--- Uptime and load average ---"
uptime

echo
echo "--- Disk usage (real disks only) ---"
df -hP -x tmpfs -x devtmpfs

echo
echo "--- Memory (in MB) ---"
free -m

echo
echo "--- Top 5 processes using the most memory ---"
ps -eo pid,user,%mem,%cpu,comm --sort=-%mem | head -n 6

echo
echo "--- Who is logged in ---"
who
