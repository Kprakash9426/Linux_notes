#!/bin/bash
# hello.sh - my very first script
echo "Hello! Today is $(date +%A), $(date '+%d %B %Y')"
echo "You are logged in as: $(whoami)"
echo "This computer is called: $(hostname)"
