#!/bin/bash
# backup.sh - make a dated .tar.gz backup of a folder, keep only the last 7 days
# Usage: ./backup.sh <folder-to-backup> [where-to-store-backups]
SOURCE="$1"
BACKUP_DIR="${2:-$HOME/backups}"
KEEP_DAYS=7

if [ -z "$SOURCE" ]; then
    echo "Usage: $0 <folder-to-backup> [where-to-store-backups]"
    exit 1
fi

if [ ! -d "$SOURCE" ]; then
    echo "ERROR: $SOURCE is not a folder"
    exit 1
fi

mkdir -p "$BACKUP_DIR"
STAMP=$(date +%Y%m%d_%H%M%S)
NAME=$(basename "$SOURCE")
FILE="$BACKUP_DIR/${NAME}_${STAMP}.tar.gz"

if tar -czf "$FILE" -C "$(dirname "$SOURCE")" "$NAME"; then
    echo "Backup created: $FILE ($(du -h "$FILE" | cut -f1))"
else
    echo "ERROR: backup failed"
    exit 1
fi

# delete backups of this folder that are older than KEEP_DAYS days
echo "Removing backups older than $KEEP_DAYS days:"
find "$BACKUP_DIR" -name "${NAME}_*.tar.gz" -mtime +"$KEEP_DAYS" -print -delete
