#!/bin/bash
# organize.sh - move the files of a folder into sub-folders by file type
# Usage: ./organize.sh [folder]     (default: current folder)
TARGET="${1:-.}"
cd "$TARGET" || exit 1

for file in *; do
    [ -f "$file" ] || continue                       # only normal files
    [ "$file" = "organize.sh" ] && continue          # never move myself

    ext="${file##*.}"                                # text after the last dot
    [ "$ext" = "$file" ] && ext="noext"              # file had no dot at all
    ext=$(echo "$ext" | tr 'A-Z' 'a-z')              # JPG -> jpg

    case "$ext" in
        jpg|jpeg|png|gif)  folder="Pictures"  ;;
        pdf|doc|docx|txt)  folder="Documents" ;;
        mp3|wav)           folder="Music"     ;;
        mp4|mkv)           folder="Videos"    ;;
        zip|tar|gz)        folder="Archives"  ;;
        *)                 folder="Others"    ;;
    esac

    mkdir -p "$folder"
    mv -n "$file" "$folder/"
    echo "Moved $file -> $folder/"
done
